## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(AMBI)
library(tidyverse)
library(lavaan)

## -----------------------------------------------------------------------------
AMBI::v_AMBI_recode_test

## -----------------------------------------------------------------------------
recode_AMBI <- function(v_AMBI){
  v_res <- ifelse(!(v_AMBI %in% c(1:5)), NA, v_AMBI)
  return(v_res)
}

## -----------------------------------------------------------------------------
AMBI::recode_AMBI(AMBI::v_AMBI_recode_test)

## -----------------------------------------------------------------------------
AMBI::df_example_elementname %>% head() %>% select(c(1:5))

## -----------------------------------------------------------------------------
calculate_AMBI(AMBI::df_example_elementname) %>% select(matches("^AMBI_MSR")) %>% head() %>% select(c(1:5))

## -----------------------------------------------------------------------------
AMBI::df_example_aliases %>% head() %>% select(c(1:5))

## -----------------------------------------------------------------------------
calculate_AMBI(AMBI::df_example_aliases,
               var_name = "aliases",
               calculation_function = "scale") %>% 
  select(matches("^AMBI_MSR")) %>% head() %>% select(c(1:5))

## -----------------------------------------------------------------------------
AMBI::df_example_elementname %>%
  calculate_AMBI() %>% 
  calculate_big5() %>% 
  select(matches("^AMBI_big5")) %>% head() %>% select(c(1:5))

## -----------------------------------------------------------------------------
AMBI::df_example_elementname %>%
  calculate_AMBI() %>% 
  calculate_big5(calculation_method = "scaling") %>% 
  select(matches("^AMBI_big5")) %>% head() %>% select(c(1:5))

## -----------------------------------------------------------------------------
big5 <- AMBI::df_example_elementname %>%
  calculate_AMBI() %>% 
  calculate_big5(calculation_method = "semscoring")

## -----------------------------------------------------------------------------
big5$dataframe %>% select(matches("^AMBI_big5")) %>% head() %>% select(c(1:5))

## -----------------------------------------------------------------------------
big5 <- AMBI::df_example_elementname %>%
  calculate_AMBI() %>% 
  calculate_big5(calculation_method = "semscoring",
                 semscoring_method = "scale")
big5$dataframe %>% select(matches("^AMBI_big5")) %>% head() %>% select(c(1:5))

## -----------------------------------------------------------------------------
big5$SEM %>% summary()

## -----------------------------------------------------------------------------
big5$SEM %>% semPlot::semPaths(whatLabels = 'est', rotation=2)

